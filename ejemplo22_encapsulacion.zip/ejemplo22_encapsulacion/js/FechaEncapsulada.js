// Una clase encapsulada es aquella que todas sus propiedades son privadas
// y se accede a ellas a través de los métodos get y set publicos
class FechaEncapsulada{
    #dia;
    #mes;
    #anyo;

    constructor(dia, mes, anyo){
        this.setDia(dia);
        this.setMes(mes);
        this.setAnyo(anyo);
    }

    getDia(){
        return this.#dia;
    }

    setDia(dia){
        if (dia > 0 && dia <= 30){
            this.#dia = dia;
        } else {
            //this.#dia = 0;
            console.log("Dia no valido");
        }
    }

    getMes(){
        return this.#mes;
    }

    setMes(mes){
        if (mes > 0 && mes <= 12){
            this.#mes = mes;
        } else {
            //this.#mes = 0;
            console.log("Mes no valido");
        }
    }

    getAnyo(){
        return this.#anyo;
    }

    setAnyo(anyo){
        if (anyo == 2022 || anyo == 2023){
            this.#anyo = anyo;
        } else {
            //this.#anyo = 0;
            console.log("Año no valido");
        }
    }

    mostrar(){
        return this.#dia + "/" + this.#mes + "/" + this.#anyo;
    }
}