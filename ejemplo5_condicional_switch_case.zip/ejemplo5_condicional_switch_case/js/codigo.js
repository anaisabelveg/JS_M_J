function cambiarColor(event){
    // Mostrar el id del boton donde se ha producido el evento
    alert(event.target.id);

    switch (event.target.id) {
        case "btn1":
            //document.getElementById("btn1").className = "rojo";
            event.target.className = "rojo";
            break;
    
        case "btn2":
            document.getElementById("btn2").className = "verde";
            break;
            
        case "btn3":
            document.getElementById("btn3").className = "azul";
            break;
                 
        default:
            break;
    }
}