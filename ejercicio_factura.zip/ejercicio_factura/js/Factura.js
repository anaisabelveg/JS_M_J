class Factura{

    #numero;
    #importe;
    #cliente;
    #fecha;
    #productos;

    static #contador = 0;

    constructor(importe, cliente, fecha, productos){
        this.#numero = ++Factura.#contador;
        this.#importe = importe;
        this.#cliente = cliente;
        this.#fecha = fecha;
        this.#productos = productos;
    }

    getNumero(){
        return this.#numero;
    }

    getImporte(){
        return this.#importe;
    }

    setImporte(importe){
        this.#importe = importe;
    }

    getCliente(){
        return this.#cliente;
    }

    setCliente(cliente){
        this.#cliente = cliente;
    }

    getFecha(){
        return this.#fecha;
    }

    setFecha(fecha){
        this.#fecha = fecha;
    } 

    getProductos(){
        return this.#productos;
    }

    setProductos(){
        this.#productos = productos;
    }

    toString(){
        return "Numero: " + this.#numero + " <br/>Importe: " + this.#importe +
            " <br/>Cliente: " + this.#cliente + " <br/>Fecha: " + this.#fecha +
            "<br/>Productos: " + this.#productos;
    }
}