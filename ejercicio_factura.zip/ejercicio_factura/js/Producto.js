class Producto{

    // Propiedades de instancia
    #id;
    #descripcion;
    #precio;

    // Propiedad de clase
    static #contador = 0;

    constructor(descripcion, precio){
        this.#id = ++Producto.#contador;   //pre-incremento
        this.#descripcion = descripcion;
        this.#precio = precio;
    }

    static getContador(){
        return Producto.#contador;
    }

    getId(){
        return this.#id;
    }

    getDescripcion(){
        return this.#descripcion;
    }

    setDescripcion(descripcion){
        this.#descripcion = descripcion;
    }

    getPrecio(){
        return this.#precio;
    }

    setPrecio(precio){
        this.#precio = precio;
    }

    toString(){
        return " ID: " + this.#id + " Descripcion: " + this.#descripcion +
            " Precio: " + this.#precio;
    }
}