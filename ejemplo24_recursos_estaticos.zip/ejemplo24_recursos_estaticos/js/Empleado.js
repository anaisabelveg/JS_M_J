// Los recursos estaticos se utilizan cuando queremos compartir
// información entre diferentes objetos.

class Empleado{

    // Propiedades de instancia (cada objeto mantiene una copia de estas propiedades)
    #numEmpleado;
    #nombre;
    #sueldo;

    // Propiedad de clase (solo existe una copia y reside en la clase)
    static #contador = 0;

    constructor(nombre, sueldo){
        // Con los recursos estaticos no utilizamos el puntero this
        // Se utiliza:  NombreClase.recursoEstatico
        Empleado.#contador += 1;
        
        this.#numEmpleado = Empleado.#contador;
        this.#nombre = nombre;
        this.#sueldo = sueldo;
    }

    // Recurso de clase (solo existe una copia y reside en la clase)
    static getContador(){
        return Empleado.#contador;
    }

    getNumEmpleado(){
        return this.#numEmpleado;
    }
    setNumEmpleado(numEmpleado){
        this.#numEmpleado = numEmpleado;
    }
    getNombre(){
        return this.#nombre;
    }
    setNombre(nombre){
        this.#nombre = nombre;
    }
    getSueldo(){
        return this.#sueldo;
    }
    setSueldo(sueldo){
        this.#sueldo = sueldo;
    }
    toString(){
        return "Numero empleado: " + this.#numEmpleado + " Nombre: " + this.#nombre +
            " Sueldo: " + this.#sueldo;
    }

    equals(otro){
        if (this.#nombre === otro.getNombre()){
            return true;
        } else {
            return false;
        }
    }
}