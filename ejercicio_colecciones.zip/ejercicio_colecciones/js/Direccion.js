class Direccion{

    #calle;
    #numero;
    #poblacion;

    constructor(calle, numero, poblacion){
        this.#calle = calle;
        this.#numero = numero;
        this.#poblacion = poblacion;
    }

    getCalle(){
        return this.#calle;
    }
    setCalle(calle){
        this.#calle = calle;
    }
    getNumero(){
        return this.#numero;
    }
    setNumero(numero){
        this.#numero = numero;
    }
    getPoblacion(){
        return this.#poblacion;
    }
    setPoblacion(poblacion){
        this.#poblacion = poblacion;
    }

    toString(){
        return this.#calle + ", " + this.#numero + " - " + this.#poblacion;
    }
}