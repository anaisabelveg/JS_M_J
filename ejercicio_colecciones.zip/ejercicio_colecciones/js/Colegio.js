class Colegio{

    #nombre;
    #direccion;
    #alumnos;
    #profesores;
    #asignaturas;

    constructor(nombre, direccion, alumnos, profesores, asignaturas){
        this.#nombre = nombre;
        this.#direccion = direccion;
        this.#alumnos = alumnos;
        this.#profesores = profesores;
        this.#asignaturas = asignaturas;
    }

    getNombre(){
        return this.#nombre;
    }
    setNombre(nombre){
        this.#nombre = nombre;
    }
    getDireccion(){
        return this.#direccion;
    }
    setDireccion(direccion){
        this.#direccion = direccion;
    }
    getAlumnos(){
        return this.#alumnos;
    }
    setAlumnos(alumnos){
        this.#alumnos = alumnos;
    }
    getProfesores(){
        return this.#profesores;
    }
    setProfesores(profesores){
        this.#profesores = profesores;
    }
    getAsignaturas(){
        return this.#asignaturas;
    }
    setAsignaturas(asignaturas){
        this.#asignaturas = asignaturas;
    }

    toString(){
        var datosProfesores = "";
        this.#profesores.forEach(item => {
            datosProfesores += item + " ";
        });

        var datosAsignaturas = "";
        for (var[profe, asignatura] of asignaturas){
            datosAsignaturas += profe + ": " + asignatura + " ";
        }

        return "Nombre: " + this.#nombre + " <br/>Direccion: " + this.#direccion +
        " <br/>Alumnos: " + alumnos + " <br/>Profesores: " + datosProfesores
        + " <br/>Asignaturas: " + datosAsignaturas;
    }
}