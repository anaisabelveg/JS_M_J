function mostrar(){
 
    console.log("Nombre: " + formulario.nombre.value);
    console.log("Pw: " + formulario.pw.value);
    console.log("Apellido: " + formulario.apellido.value);
    console.log("Edad: " + formulario.edad.value);
    console.log("Email: " + formulario.email.value);
    console.log("Sitio web: " + formulario.web.value);
    console.log("Telefono: " + formulario.telefono.value);
    console.log("Fecha nacimiento: " + formulario.nacimiento.value);
    console.log("Sexo: " + formulario.sexo.value);
    console.log("Estudios: " + formulario.estudios.value);

    for (let i in document.getElementById("cursos").options){
        if (document.getElementById("cursos").options[i].selected){
            console.log("Cursos: " + document.getElementById("cursos").options[i].text)
        }
    }
}