function funcMatematicas(){
    document.write("log 1000: " + Math.log(1000) + "<br/>");
    document.write("exp 7: " + Math.exp(7) + "<br/>");
    document.write("raiz de 9: " + Math.sqrt(9) + "<br/>");
    document.write("potencia 5 elevado a 3: " + Math.pow(5,3) + "<br/>");
    document.write("Absoluto -56.4322: " + Math.abs(-56.4322) + "<br/>");
    document.write("redondeo baja 534.523: " + Math.floor(534.523) + "<br/>");
    document.write("redondeo alto 534.523: " + Math.ceil(534.523) + "<br/>");
    document.write("redondeo medio 534.523: " + Math.round(534.523) + "<br/>");
    document.write("aleatorio: " + Math.random() + "<br/>");
    document.write("coseno de 100: " + Math.cos(100) + "<br/>");
    document.write("maximo: " + Math.max(6,1,4,9,23,67,45) + "<br/>");
    document.write("minimo: " + Math.min(6,1,4,9,23,67,45) + "<br/>");
    document.write("PI: " + Math.PI + "<br/>");
    document.write("E: " + Math.E + "<br/>");
    document.write("Area de un circulo: " + (Math.PI * Math.pow(56,2)) + "<br/>");
    with(Math){
        document.write("Area de un circulo: " + (PI * pow(56,2)) + "<br/>");
    }
}