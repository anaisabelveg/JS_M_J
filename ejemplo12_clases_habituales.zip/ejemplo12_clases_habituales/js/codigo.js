function funcFechas(){
    var hoy = new Date();
    document.write("Hoy: " + hoy + "<br/>");
    document.write("getTime: " + hoy.getTime() + "<br/>");
    document.write("Diferencia horaria: " + hoy.getTimezoneOffset() + "<br/>");
    document.write("Dia de la semana (0-6): " + hoy.getDay() + "<br/>");
    document.write("Dia del mes: " + hoy.getDate() + "<br/>");
    document.write("Mes (0-11): " + hoy.getMonth() + "<br/>");
    document.write("Año 2 cifras: " + hoy.getYear() + "<br/>");
    document.write("Año 4 cifras: " + hoy.getFullYear() + "<br/>");
    document.write("Horas: " + hoy.getHours() + "<br/>");
    document.write("Minutos: " + hoy.getMinutes() + "<br/>");
    document.write("Segundos: " + hoy.getSeconds() + "<br/>");
    document.write("Milisegundos: " + hoy.getMilliseconds() + "<br/>");
}


function funcTexto(){
    var texto = "Esto es un texto para probar las funciones String";

    document.write("caracter unicode 74: " + String.fromCharCode(74) + "<br/>");
    document.write("unicode letra o: " + texto.charCodeAt(3) + "<br/>");
    document.write("indexOf letra a: " + texto.indexOf("a") + "<br/>");
    document.write("lastindexOf letra a: " + texto.lastIndexOf("a") + "<br/>");
    document.write("longitud texto: " + texto.length + "<br/>");
    document.write("substr 3,6: " + texto.substr(3,6) + "<br/>");
    document.write("substr 3: " + texto.substr(3) + "<br/>");
    document.write("slice 3: " + texto.slice(3) + "<br/>");
    document.write("slice 3,6: " + texto.slice(3,6) + "<br/>");
    document.write("substring 3,6: " + texto.substring(3,6) + "<br/>");
    document.write("substring 3: " + texto.substring(3) + "<br/>");
    document.write("minusculas: " + texto.toLowerCase() + "<br/>");
    document.write("mayusculas: " + texto.toUpperCase() + "<br/>");
    var datos = "15/11/2022".split("/");
    document.write("dia: " + datos[0] + "<br/>");
    document.write("mes: " + datos[1] + "<br/>");
    document.write("año: " + datos[2] + "<br/>");
}

function funcMatematicas(){
    document.write("log 1000: " + Math.log(1000) + "<br/>");
    document.write("exp 7: " + Math.exp(7) + "<br/>");
    document.write("raiz de 9: " + Math.sqrt(9) + "<br/>");
    document.write("potencia 5 elevado a 3: " + Math.pow(5,3) + "<br/>");
    document.write("Absoluto -56.4322: " + Math.abs(-56.4322) + "<br/>");
    document.write("redondeo baja 534.523: " + Math.floor(534.523) + "<br/>");
    document.write("redondeo alto 534.523: " + Math.ceil(534.523) + "<br/>");
    document.write("redondeo medio 534.523: " + Math.round(534.523) + "<br/>");
    document.write("aleatorio: " + Math.random() + "<br/>");
    document.write("coseno de 100: " + Math.cos(100) + "<br/>");
    document.write("maximo: " + Math.max(6,1,4,9,23,67,45) + "<br/>");
    document.write("minimo: " + Math.min(6,1,4,9,23,67,45) + "<br/>");
    document.write("PI: " + Math.PI + "<br/>");
    document.write("E: " + Math.E + "<br/>");
    document.write("Area de un circulo: " + (Math.PI * Math.pow(56,2)) + "<br/>");
    with(Math){
        document.write("Area de un circulo: " + (PI * pow(56,2)) + "<br/>");
    }
}