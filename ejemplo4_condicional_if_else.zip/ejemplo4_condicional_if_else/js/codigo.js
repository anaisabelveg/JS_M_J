var estiloBorde = false;   // false: no tiene borde, true: si lo tiene
var estiloColor = false;
var estiloSombra = false;

const cuadrado = document.querySelector("#cuadrado");

function borde(){
    if (!estiloBorde){
        cuadrado.style.border = "5px solid blue";
        estiloBorde = true;
    } else {
        document.getElementById("cuadrado").style.border = "none";
        estiloBorde = false;
    }
}

function color(){
    if (!estiloColor){
        cuadrado.style.backgroundColor = "yellow";
    } else {
        cuadrado.style.backgroundColor = "gainsboro";
    }
    estiloColor = !estiloColor;
}

function sombra(){
    if (!estiloSombra){
        cuadrado.className = "sombra";
    } else {
        cuadrado.className = null;
    }
    estiloSombra = !estiloSombra;
}

