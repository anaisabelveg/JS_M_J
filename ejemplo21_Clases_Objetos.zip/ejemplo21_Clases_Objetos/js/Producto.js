class Producto{

    id;
    descripcion;
    precio;

    constructor(id, descripcion, precio){
        this.id = id;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    mostrar(){
        return "ID: " + this.id + 
            " Descripcion: " + this.descripcion + 
            " Precio: " + this.precio;
    }
}